package com.nothing4apro.hamsterwheel

import android.app.Service
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.Message
import android.os.Messenger
import android.util.Log
import com.nothing.ketchum.GlyphToy

/**
 * Official Nothing OS Glyph Toy Service for Nothing Phone (4a) Pro (`Glyph.DEVICE_25111p`).
 *
 * Registered in AndroidManifest.xml with:
 * - Action: `com.nothing.glyph.TOY`
 * - Meta-data: `com.nothing.glyph.toy.aod_support = 1`
 *
 * When selected under Settings -> Glyph Interface -> Always-on Glyph Toy, Nothing OS binds
 * this service and sends periodic `GlyphToy.EVENT_AOD` messages. We also start
 * [HamsterForegroundService] so that waking the screen (`ACTION_SCREEN_ON`) never interrupts
 * the animation.
 */
class HamsterToyService : Service() {

    companion object {
        private const val TAG = "HamsterToyService"
    }

    private val serviceHandler = object : Handler(Looper.getMainLooper()) {
        override fun handleMessage(msg: Message) {
            if (msg.what == GlyphToy.MSG_GLYPH_TOY) {
                val bundle = msg.data
                val event = bundle?.getString(GlyphToy.MSG_GLYPH_TOY_DATA)
                when (event) {
                    GlyphToy.EVENT_AOD -> {
                        // Nothing OS sends EVENT_AOD every minute in AOD mode; ensure engine is running
                        HamsterAnimatorEngine.start(applicationContext)
                    }
                    GlyphToy.EVENT_CHANGE -> {
                        // Optional long-press test: toggle simulated run / deceleration
                        val currentOverride = HamsterAnimatorEngine.manualChargingOverride
                        val next = if (currentOverride == null) {
                            !HamsterAnimatorEngine.isChargingNow
                        } else {
                            !currentOverride
                        }
                        HamsterAnimatorEngine.setManualOverride(next)
                    }
                }
            } else {
                super.handleMessage(msg)
            }
        }
    }

    private val serviceMessenger = Messenger(serviceHandler)

    override fun onBind(intent: Intent?): IBinder {
        Log.i(TAG, "HamsterToyService bound by Nothing OS")
        HamsterAnimatorEngine.setToyBound(true)
        HamsterAnimatorEngine.start(applicationContext)
        HamsterForegroundService.startService(applicationContext)
        return serviceMessenger.binder
    }

    override fun onUnbind(intent: Intent?): Boolean {
        Log.i(TAG, "HamsterToyService unbound by Nothing OS")
        HamsterAnimatorEngine.setToyBound(false)
        // Crucial: Do NOT stop HamsterAnimatorEngine here if the user woke the screen!
        // HamsterForegroundService keeps the animation alive while the screen is active.
        return false
    }
}
