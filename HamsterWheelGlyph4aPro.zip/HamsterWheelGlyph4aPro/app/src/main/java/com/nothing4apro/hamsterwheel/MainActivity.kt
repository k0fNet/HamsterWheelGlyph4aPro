package com.nothing4apro.hamsterwheel

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

/**
 * Companion UI for the Nothing Phone (4a) Pro Hamster Wheel Glyph Toy.
 *
 * Features:
 * - Live 13×13 (137 LED) interactive preview mirroring the physical Glyph Matrix
 * - Displays current state (SLEEPING, RUNNING, DECELERATING) and frame interval (ms)
 * - Buttons to test Charging / Unplugging deceleration directly without plugging a cable
 * - Direct shortcut to Nothing OS "Always-on Glyph Toy" settings (`AodToySelectActivity`)
 */
class MainActivity : AppCompatActivity(), HamsterAnimatorEngine.FrameListener {

    private lateinit var previewView: GlyphMatrixPreviewView
    private lateinit var stateBadgeText: TextView
    private lateinit var detailsText: TextView
    private lateinit var simulateBtn: Button
    private lateinit var resetAutoBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        requestNotificationPermissionIfNeeded()

        // Start foreground service so Glyph Matrix stays active even when screen is ON
        HamsterForegroundService.startService(this)
        HamsterAnimatorEngine.start(this)

        setContentView(buildNothingStyledUi())
    }

    override fun onResume() {
        super.onResume()
        HamsterAnimatorEngine.addListener(this)
    }

    override fun onPause() {
        HamsterAnimatorEngine.removeListener(this)
        super.onPause()
    }

    override fun onFrameUpdated(
        frame169: IntArray,
        state: HamsterAnimatorEngine.State,
        frameDelayMs: Long,
        isCharging: Boolean
    ) {
        runOnUiThread {
            previewView.updateFrame(frame169)
            val stateLabel = when (state) {
                HamsterAnimatorEngine.State.SLEEPING -> "СОСТОЯНИЕ: СПИТ (SLEEPING)"
                HamsterAnimatorEngine.State.RUNNING -> "СОСТОЯНИЕ: БЕЖИТ В КОЛЕСЕ (RUNNING)"
                HamsterAnimatorEngine.State.DECELERATING -> "СОСТОЯНИЕ: ЗАМЕДЛЯЕТСЯ (DECELERATING)"
            }
            stateBadgeText.text = stateLabel

            val modeStr = if (HamsterAnimatorEngine.manualChargingOverride != null) {
                "Ручной тест"
            } else {
                "Авто (от кабеля USB)"
            }
            val powerStr = if (isCharging) "Зарядка подключена ⚡" else "Отключено от сети 🔋"
            detailsText.text = "Матрица: 13×13 (137 LED · Phone 4a Pro)\n" +
                    "Питание: $powerStr ($modeStr)\n" +
                    "Задержка кадра: ${frameDelayMs} мс · Экран активен: Да"

            simulateBtn.text = if (isCharging) {
                "Симулировать отключение зарядки (Плавная остановка)"
            } else {
                "Симулировать подключение зарядки (Запуск колеса)"
            }
        }
    }

    private fun buildNothingStyledUi(): ScrollView {
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#0A0A0C"))
            isFillViewport = true
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            val pad = dp(20)
            setPadding(pad, dp(32), pad, pad)
        }

        val title = TextView(this).apply {
            text = "HAMSTER WHEEL · 4A PRO"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "Glyph Matrix 13×13 (137 mini-LEDs) · DEVICE_25111p"
            setTextColor(Color.parseColor("#8E8E96"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            setPadding(0, dp(4), 0, dp(20))
        }
        root.addView(subtitle)

        previewView = GlyphMatrixPreviewView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dp(260), dp(260)).apply {
                bottomMargin = dp(20)
            }
        }
        root.addView(previewView)

        stateBadgeText = TextView(this).apply {
            text = "СОСТОЯНИЕ: СПИТ"
            setTextColor(Color.parseColor("#FF3B30"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(8), dp(16), dp(8))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#18181C"))
                cornerRadius = dp(12).toFloat()
                setStroke(dp(1), Color.parseColor("#2E2E36"))
            }
        }
        root.addView(stateBadgeText)

        detailsText = TextView(this).apply {
            setTextColor(Color.parseColor("#C8C8D0"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.MONOSPACE
            gravity = Gravity.CENTER
            setPadding(0, dp(14), 0, dp(20))
        }
        root.addView(detailsText)

        simulateBtn = createActionButton(
            "Симулировать подключение зарядки",
            bgColor = "#D71921",
            textColor = "#FFFFFF"
        ) {
            val currentlyActive = HamsterAnimatorEngine.manualChargingOverride
                ?: HamsterAnimatorEngine.isChargingNow
            HamsterAnimatorEngine.setManualOverride(!currentlyActive)
        }
        root.addView(simulateBtn)

        resetAutoBtn = createActionButton(
            "Режим Авто (реакция на реальный кабель зарядки)",
            bgColor = "#1C1C22",
            textColor = "#E0E0E6"
        ) {
            HamsterAnimatorEngine.setManualOverride(null)
            HamsterAnimatorEngine.syncBatteryChargingState(this)
            Toast.makeText(this, "Включен автоматический режим от USB/беспроводной зарядки", Toast.LENGTH_SHORT).show()
        }
        root.addView(resetAutoBtn)

        val openAodToyBtn = createActionButton(
            "Открыть настройки Always-On Glyph Toy (Phone 4a Pro)",
            bgColor = "#1C1C22",
            textColor = "#FFFFFF"
        ) {
            openNothingGlyphToySettings()
        }
        root.addView(openAodToyBtn)

        scroll.addView(root)
        return scroll
    }

    private fun createActionButton(
        label: String,
        bgColor: String,
        textColor: String,
        onClick: () -> Unit
    ): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.parseColor(textColor))
            typeface = Typeface.MONOSPACE
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            background = GradientDrawable().apply {
                setColor(Color.parseColor(bgColor))
                cornerRadius = dp(14).toFloat()
                setStroke(dp(1), Color.parseColor("#34343E"))
            }
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = dp(12)
            }
            setPadding(dp(16), dp(14), dp(16), dp(14))
            setOnClickListener { onClick() }
        }
    }

    private fun openNothingGlyphToySettings() {
        // 1. Try Nothing Phone (4a) Pro AOD Toy picker activity directly
        try {
            val aodIntent = Intent().apply {
                component = ComponentName(
                    "com.nothing.thirdparty",
                    "com.nothing.thirdparty.matrix.toys.manager.AodToySelectActivity"
                )
            }
            startActivity(aodIntent)
            return
        } catch (_: Throwable) {}

        // 2. Fallback to standard Nothing ToysManagerActivity
        try {
            val managerIntent = Intent().apply {
                component = ComponentName(
                    "com.nothing.thirdparty",
                    "com.nothing.thirdparty.matrix.toys.manager.ToysManagerActivity"
                )
            }
            startActivity(managerIntent)
            return
        } catch (_: Throwable) {}

        // 3. Fallback to system Settings
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS))
            Toast.makeText(
                this,
                "Откройте: Settings → Glyph Interface → Always-on Glyph Toy",
                Toast.LENGTH_LONG
            ).show()
        } catch (_: Throwable) {}
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    1001
                )
            }
        }
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }
}
