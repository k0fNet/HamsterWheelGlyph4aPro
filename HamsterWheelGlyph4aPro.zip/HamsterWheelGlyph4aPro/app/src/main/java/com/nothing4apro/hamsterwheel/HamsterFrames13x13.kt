package com.nothing4apro.hamsterwheel

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.atan2

/**
 * Pixel art frame generator strictly calibrated for the Nothing Phone (4a) Pro Glyph Matrix.
 *
 * Matrix specification for Nothing Phone (4a) Pro (`Glyph.DEVICE_25111p`):
 * - Logical square grid: 13 × 13 (169 cells)
 * - Active circular PCB LEDs: 137 physical mini-LEDs
 * - Row pattern (top to bottom): [5, 9, 11, 11, 13, 13, 13, 13, 13, 11, 11, 9, 5]
 *   (Phone (3) uses 25 × 25 with 489 LEDs; this class targets the 13 × 13 matrix exclusively.)
 */
object HamsterFrames13x13 {

    const val MATRIX_SIZE = 13
    const val TOTAL_CELLS = MATRIX_SIZE * MATRIX_SIZE // 169

    val ROWS_13 = intArrayOf(5, 9, 11, 11, 13, 13, 13, 13, 13, 11, 11, 9, 5)

    // Precomputed 36 outer rim coordinates in clockwise order around center (6, 6)
    val RIM_RING: List<Pair<Int, Int>> by lazy {
        val list = mutableListOf<Triple<Double, Int, Int>>()
        for (r in 0 until MATRIX_SIZE) {
            for (c in 0 until MATRIX_SIZE) {
                if (!isValidCell(r, c)) continue
                if (!isValidCell(r - 1, c) || !isValidCell(r + 1, c) ||
                    !isValidCell(r, c - 1) || !isValidCell(r, c + 1)
                ) {
                    val angle = atan2((r - 6).toDouble(), (c - 6).toDouble())
                    list.add(Triple(angle, r, c))
                }
            }
        }
        list.sortedBy { it.first }.map { Pair(it.second, it.third) }
    }

    /**
     * Checks whether (row, col) falls inside the 137-LED circular mask of the Phone (4a) Pro.
     */
    fun isValidCell(r: Int, c: Int): Boolean {
        if (r !in 0 until MATRIX_SIZE || c !in 0 until MATRIX_SIZE) return false
        val ledsInRow = ROWS_13[r]
        val colStart = (MATRIX_SIZE - ledsInRow) / 2
        return c in colStart until (colStart + ledsInRow)
    }

    /**
     * Builds the wheel rim + rotating spokes + central hub on the 13x13 grid.
     */
    private fun buildWheelBase(wheelPhase: Int, isSleeping: Boolean): IntArray {
        val grid = IntArray(TOTAL_CELLS)
        val nRim = RIM_RING.size // 36 LEDs on the circular perimeter
        val quarter = nRim / 4  // 9 LEDs per quadrant
        val shift = ((wheelPhase % quarter) + quarter) % quarter

        for ((idx, pos) in RIM_RING.withIndex()) {
            val (r, c) = pos
            val baseBrightness = if (isSleeping) 55 else 85
            val rem = ((idx - shift * 2) % quarter + quarter) % quarter
            val isSpokeMarker = (rem == 0)

            val value = when {
                isSpokeMarker && !isSleeping -> 220
                isSpokeMarker && isSleeping -> 95
                else -> baseBrightness
            }
            grid[r * MATRIX_SIZE + c] = value
        }

        // Wheel center hub at (5, 6)
        grid[5 * MATRIX_SIZE + 6] = if (isSleeping) 65 else 110
        return grid
    }

    /**
     * Generates a sleeping hamster frame (default idle state when not charging).
     * @param breathPhase 0 or 1 (slow breathing + rising "Zzz" sleep bubbles)
     */
    fun getSleepingFrame(breathPhase: Int): IntArray {
        val phase = breathPhase and 1
        val grid = buildWheelBase(wheelPhase = 0, isSleeping = true)
        val bodyEdge = if (phase == 0) 225 else 195

        // Curled sleeping hamster resting at the bottom of the wheel (rows 7..10, cols 4..9)
        val bodyPixels = mutableListOf(
            Triple(8, 5, bodyEdge), Triple(8, 6, bodyEdge), Triple(8, 7, bodyEdge),
            Triple(9, 4, bodyEdge), Triple(9, 5, 255), Triple(9, 6, 255), Triple(9, 7, 255), Triple(9, 8, bodyEdge),
            Triple(10, 5, 180), Triple(10, 6, 180), Triple(10, 7, 180),
            // Little ear on head
            Triple(7, 4, 255), Triple(8, 4, 240),
            // Stubby tail on right
            Triple(9, 9, 140)
        )

        if (phase == 1) {
            // Subtle breathing chest rise
            bodyPixels.add(Triple(7, 6, 175))
            bodyPixels.add(Triple(7, 7, 155))
        }

        for ((r, c, b) in bodyPixels) {
            if (isValidCell(r, c)) {
                grid[r * MATRIX_SIZE + c] = b
            }
        }

        // Floating Zzz sleep particles above the hamster
        val zzzPixels = if (phase == 0) {
            listOf(Triple(5, 8, 170), Triple(4, 9, 120), Triple(3, 7, 90))
        } else {
            listOf(Triple(4, 8, 190), Triple(3, 9, 150), Triple(2, 7, 110))
        }

        for ((r, c, b) in zzzPixels) {
            if (isValidCell(r, c)) {
                grid[r * MATRIX_SIZE + c] = b
            }
        }

        return grid
    }

    /**
     * Generates a running hamster frame (active when charging or decelerating after unplugging).
     * @param stepPhase 0..3 (4-step gallop + wheel rotation)
     */
    fun getRunningFrame(stepPhase: Int): IntArray {
        val phase = ((stepPhase % 4) + 4) % 4
        val grid = buildWheelBase(wheelPhase = phase, isSleeping = false)

        // Slight vertical bounce during mid-stride (phase 1)
        val bob = if (phase == 1) -1 else 0
        val headRow = 7 + bob

        val bodyPixels = listOf(
            // Upright ear
            Triple(headRow - 1, 7, 240),
            // Head & snout facing right
            Triple(headRow, 7, 255), Triple(headRow, 8, 255), Triple(headRow, 9, 225),
            Triple(headRow + 1, 7, 255), Triple(headRow + 1, 8, 245),
            // Plump hamster torso
            Triple(8 + bob, 4, 230), Triple(8 + bob, 5, 255), Triple(8 + bob, 6, 255),
            Triple(9 + bob, 4, 220), Triple(9 + bob, 5, 255), Triple(9 + bob, 6, 255), Triple(9 + bob, 7, 240),
            // Stubby tail on the left
            Triple(8 + bob, 3, 190)
        )

        for ((r, c, b) in bodyPixels) {
            if (isValidCell(r, c)) {
                grid[r * MATRIX_SIZE + c] = b
            }
        }

        // 4-frame animated paw cycle at the bottom of the wheel
        val legPixels = when (phase) {
            0 -> listOf(Triple(10, 3, 255), Triple(10, 4, 180), Triple(10, 8, 180), Triple(10, 9, 255))
            1 -> listOf(Triple(9, 3, 240), Triple(10, 5, 255), Triple(10, 7, 255), Triple(9, 9, 240))
            2 -> listOf(Triple(10, 5, 255), Triple(10, 6, 255), Triple(10, 7, 255))
            else -> listOf(Triple(10, 4, 255), Triple(10, 5, 190), Triple(10, 7, 190), Triple(10, 8, 255))
        }

        for ((r, c, b) in legPixels) {
            if (isValidCell(r, c)) {
                grid[r * MATRIX_SIZE + c] = b
            }
        }

        return grid
    }

    /**
     * Converts a 13x13 brightness array (0..255) into a 13x13 ARGB_8888 Bitmap
     * suitable for `GlyphMatrixObject.Builder().setImageSource(bitmap)`.
     */
    fun toBitmap(frame169: IntArray): Bitmap {
        val pixels = IntArray(TOTAL_CELLS)
        for (i in 0 until TOTAL_CELLS) {
            val r = i / MATRIX_SIZE
            val c = i % MATRIX_SIZE
            val b = if (isValidCell(r, c)) frame169[i].coerceIn(0, 255) else 0
            pixels[i] = if (b > 0) Color.argb(255, b, b, b) else Color.TRANSPARENT
        }
        return Bitmap.createBitmap(pixels, MATRIX_SIZE, MATRIX_SIZE, Bitmap.Config.ARGB_8888)
    }
}
