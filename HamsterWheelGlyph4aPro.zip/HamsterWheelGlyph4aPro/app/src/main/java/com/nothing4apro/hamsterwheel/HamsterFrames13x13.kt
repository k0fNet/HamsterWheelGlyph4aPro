package com.nothing4apro.hamsterwheel

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Pixel-accurate 13×13 (137 mini-LEDs) frame generator matching the "Charging Hamster"
 * design for Nothing Phone (4a) Pro (`Glyph.DEVICE_25111p`).
 *
 * Matrix specification:
 * - Logical grid: 13 × 13 (169 cells)
 * - Active circular LEDs: 137 physical LEDs (`ROWS_13 = [5, 9, 11, 11, 13, 13, 13, 13, 13, 11, 11, 9, 5]`)
 */
object HamsterFrames13x13 {

    const val MATRIX_SIZE = 13
    const val TOTAL_CELLS = MATRIX_SIZE * MATRIX_SIZE // 169

    val ROWS_13 = intArrayOf(5, 9, 11, 11, 13, 13, 13, 13, 13, 11, 11, 9, 5)

    private const val WHEEL_BRIGHTNESS = 75
    private const val HAMSTER_BRIGHTNESS = 255

    // Exact 36 outer rim coordinates on the 13x13 circular mask
    private val RIM_COORDS: List<Pair<Int, Int>> = listOf(
        Pair(0, 4), Pair(0, 5), Pair(0, 6), Pair(0, 7), Pair(0, 8),
        Pair(1, 2), Pair(1, 3), Pair(1, 9), Pair(1, 10),
        Pair(2, 1), Pair(2, 11),
        Pair(3, 1), Pair(3, 11),
        Pair(4, 0), Pair(4, 12),
        Pair(5, 0), Pair(5, 12),
        Pair(6, 0), Pair(6, 12),
        Pair(7, 0), Pair(7, 12),
        Pair(8, 0), Pair(8, 12),
        Pair(9, 1), Pair(9, 11),
        Pair(10, 1), Pair(10, 11),
        Pair(11, 2), Pair(11, 3), Pair(11, 9), Pair(11, 10),
        Pair(12, 4), Pair(12, 5), Pair(12, 6), Pair(12, 7), Pair(12, 8)
    )

    private val RIM_SET: Set<Pair<Int, Int>> = RIM_COORDS.toSet()

    // Exact 4 rotating wheel spoke states extracted from the Charging Hamster reference
    private val SPOKE_PHASES: Array<List<Pair<Int, Int>>> = arrayOf(
        // Phase 0: 45° diagonal X-spokes (Sleep state & Run stride 0)
        listOf(
            Pair(2, 2), Pair(3, 3), Pair(4, 4), Pair(5, 5),
            Pair(2, 10), Pair(3, 9), Pair(4, 8), Pair(5, 7),
            Pair(6, 6),
            Pair(7, 5), Pair(8, 4), Pair(9, 3), Pair(10, 2),
            Pair(7, 7), Pair(8, 8), Pair(9, 9), Pair(10, 10)
        ),
        // Phase 1: Tilted spokes A (Screenshot 3 / Run stride 1)
        listOf(
            Pair(1, 4), Pair(2, 4), Pair(3, 5), Pair(4, 5), Pair(5, 5),
            Pair(4, 10), Pair(4, 11), Pair(5, 7), Pair(5, 8), Pair(5, 9),
            Pair(6, 6),
            Pair(7, 3), Pair(7, 4), Pair(7, 5), Pair(8, 1), Pair(8, 2),
            Pair(7, 7), Pair(8, 7), Pair(9, 8), Pair(10, 8), Pair(11, 8)
        ),
        // Phase 2: 90° orthogonal '+' cross spokes (Run stride 2)
        listOf(
            Pair(1, 6), Pair(2, 6), Pair(3, 6), Pair(4, 6), Pair(5, 6),
            Pair(6, 1), Pair(6, 2), Pair(6, 3), Pair(6, 4), Pair(6, 5),
            Pair(6, 6),
            Pair(6, 7), Pair(6, 8), Pair(6, 9), Pair(6, 10), Pair(6, 11),
            Pair(7, 6), Pair(8, 6), Pair(9, 6), Pair(10, 6), Pair(11, 6)
        ),
        // Phase 3: Tilted spokes B (Screenshot 4 / Run stride 3)
        listOf(
            Pair(1, 8), Pair(2, 8), Pair(3, 7), Pair(4, 7), Pair(5, 7),
            Pair(4, 1), Pair(4, 2), Pair(5, 3), Pair(5, 4), Pair(5, 5),
            Pair(6, 5), Pair(6, 6), Pair(6, 7),
            Pair(7, 6), Pair(8, 5), Pair(9, 5), Pair(10, 4), Pair(11, 4),
            Pair(7, 8), Pair(7, 9), Pair(8, 10), Pair(8, 11)
        )
    )

    // 14-step sleep cycle: breathing back + single-pixel sleep particles drifting up and off the top of the wheel
    private data class SleepStep(val expandedBack: Boolean, val particles: List<Pair<Int, Int>>)

    private val SLEEP_STEPS: List<SleepStep> = listOf(
        SleepStep(false, listOf(Pair(8, 7))),
        SleepStep(false, listOf(Pair(7, 7))),
        SleepStep(false, listOf(Pair(6, 7))),
        SleepStep(false, listOf(Pair(5, 8))),
        SleepStep(false, listOf(Pair(4, 9))),
        SleepStep(true,  listOf(Pair(3, 10))),                // Matches Screenshot 2
        SleepStep(false, listOf(Pair(2, 10), Pair(8, 9))),
        SleepStep(false, listOf(Pair(1, 9),  Pair(7, 9))),    // Upper particle reaches top rim and exits
        SleepStep(false, listOf(Pair(6, 9))),
        SleepStep(false, listOf(Pair(5, 8))),
        SleepStep(true,  listOf(Pair(4, 7))),
        SleepStep(false, listOf(Pair(3, 6),  Pair(8, 7))),
        SleepStep(false, listOf(Pair(2, 6),  Pair(7, 7))),    // Matches Screenshot 1
        SleepStep(false, listOf(Pair(1, 7),  Pair(6, 7)))     // Upper particle reaches top rim and exits
    )

    const val SLEEP_CYCLE_LENGTH = 14
    const val WHEEL_LOOP_STEPS = 12

    fun isValidCell(r: Int, c: Int): Boolean {
        if (r !in 0 until MATRIX_SIZE || c !in 0 until MATRIX_SIZE) return false
        val ledsInRow = ROWS_13[r]
        val colStart = (MATRIX_SIZE - ledsInRow) / 2
        return c in colStart until (colStart + ledsInRow)
    }

    private fun buildWheelBase(spokePhase: Int): IntArray {
        val grid = IntArray(TOTAL_CELLS)
        for ((r, c) in RIM_COORDS) {
            grid[r * MATRIX_SIZE + c] = WHEEL_BRIGHTNESS
        }
        val phase = ((spokePhase % 4) + 4) % 4
        for ((r, c) in SPOKE_PHASES[phase]) {
            if (isValidCell(r, c)) {
                grid[r * MATRIX_SIZE + c] = WHEEL_BRIGHTNESS
            }
        }
        return grid
    }

    /**
     * Generates a sleeping hamster frame with single-pixel sleep particles floating up and off-screen.
     */
    fun getSleepingFrame(stepIndex: Int): IntArray {
        val step = SLEEP_STEPS[((stepIndex % SLEEP_STEPS.size) + SLEEP_STEPS.size) % SLEEP_STEPS.size]
        val grid = buildWheelBase(spokePhase = 0)

        // Curled sleeping hamster dome at the bottom of the wheel:
        // Row 9: cols 6..7 (expands to 6..8 when breathing in)
        // Row 10: cols 5..8
        // Row 11: cols 4..8
        val row9Cols = if (step.expandedBack) intArrayOf(6, 7, 8) else intArrayOf(6, 7)
        for (c in row9Cols) {
            grid[9 * MATRIX_SIZE + c] = HAMSTER_BRIGHTNESS
        }
        for (c in 5..8) {
            grid[10 * MATRIX_SIZE + c] = HAMSTER_BRIGHTNESS
        }
        for (c in 4..8) {
            grid[11 * MATRIX_SIZE + c] = HAMSTER_BRIGHTNESS
        }

        // Single-pixel sleep particles drifting up and out of the matrix
        for ((r, c) in step.particles) {
            if (isValidCell(r, c)) {
                grid[r * MATRIX_SIZE + c] = HAMSTER_BRIGHTNESS
            }
        }

        return grid
    }

    /**
     * Generates a running hamster frame matching Screenshots 3 & 4 (dark eye at (9,7), ear at (8,7),
     * 4-phase rotating spokes + 4-phase distinct paw strides on row 11).
     */
    fun getRunningFrame(stepIndex: Int): IntArray {
        val phase = ((stepIndex % 4) + 4) % 4
        val grid = buildWheelBase(spokePhase = phase)

        // Hamster body facing right with dark eye cutout at (9, 7)
        val bodyPixels = listOf(
            Pair(8, 7),                                         // Ear
            Pair(9, 5), Pair(9, 6), Pair(9, 8),                 // Head & snout ((9,7) is eye)
            Pair(10, 4), Pair(10, 5), Pair(10, 6), Pair(10, 7), Pair(10, 8) // Torso
        )
        for ((r, c) in bodyPixels) {
            grid[r * MATRIX_SIZE + c] = HAMSTER_BRIGHTNESS
        }
        // Explicitly keep eye at (9, 7) dark (0) even if a spoke passes behind it
        grid[9 * MATRIX_SIZE + 7] = 0

        // 4-step running leg cycle on row 11
        val legs = when (phase) {
            0 -> listOf(Pair(11, 3), Pair(11, 7)) // Wide stride A
            1 -> listOf(Pair(11, 4), Pair(11, 8)) // Screenshot 3 stride
            2 -> listOf(Pair(11, 5), Pair(11, 7)) // Gathered stride
            else -> listOf(Pair(11, 4), Pair(11, 6)) // Screenshot 4 stride
        }
        for ((r, c) in legs) {
            grid[r * MATRIX_SIZE + c] = HAMSTER_BRIGHTNESS
        }

        return grid
    }

    /**
     * Generates a frame where the hamster clings to the inside of the wheel and makes one full
     * 360-degree loop (`loopStep` 0..11) as the wheel decelerates to a stop after unplugging.
     */
    fun getWheelLoopFrame(loopStep: Int): IntArray {
        val step = ((loopStep % WHEEL_LOOP_STEPS) + WHEEL_LOOP_STEPS) % WHEEL_LOOP_STEPS
        val grid = buildWheelBase(spokePhase = step % 4)

        // Counter-clockwise 360° loop starting from bottom (90° -> 60° -> 30° -> 0° [right wall] -> -90° [top] -> -180° [left wall] -> -270° [bottom])
        val angleRad = Math.toRadians(90.0 - step * (360.0 / WHEEL_LOOP_STEPS))
        val cx = 6.0 + 3.5 * cos(angleRad)
        val cy = 6.0 + 3.5 * sin(angleRad)

        for (r in 0 until MATRIX_SIZE) {
            for (c in 0 until MATRIX_SIZE) {
                if (!isValidCell(r, c)) continue
                if (RIM_SET.contains(Pair(r, c))) continue
                if (hypot(r - cy, c - cx) <= 1.65) {
                    grid[r * MATRIX_SIZE + c] = HAMSTER_BRIGHTNESS
                }
            }
        }
        return grid
    }

    /**
     * Converts a 13×13 brightness array (0..255) into a 13×13 ARGB_8888 Bitmap for GlyphMatrixObject.
     */
    fun toBitmap(frame169: IntArray): Bitmap {
        val pixels = IntArray(TOTAL_CELLS)
        for (i in 0 until TOTAL_CELLS) {
            val r = i / MATRIX_SIZE
            val c = i % MATRIX_SIZE
            val b = if (isValidCell(r, c)) frame169[i].coerceIn(0, 255) else 0
            pixels[i] = if (b > 0) Color.argb(255, b, b, b) else Color.TRANSPARENT
        }
        return Bitmap.createBitmap(pixels, MATRIX_SIZE, MATRIX_SIZE, Bitmap.Config.ARGB_8888)
    }
}
