package com.nothing4apro.hamsterwheel

import android.graphics.Bitmap
import android.graphics.Color
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Pixel-accurate 13×13 (137 mini-LEDs) frame generator matching the "Charging Hamster"
 * design for Nothing Phone (4a) Pro (`Glyph.DEVICE_25111p`).
 *
 * Updates in v1.2:
 * 1. Seamless 160-step (30.4-second) sleep cycle: each single-pixel sleep particle spawns at row 8
 *    and rises strictly 1 row per step (`r = 8 -> 7 -> ... -> 1`) before exiting off the top of the
 *    matrix, with zero jumps or loop seams.
 * 2. Clockwise (по часовой стрелке) wheel rotation & 360° unplug ride: since the hamster runs facing
 *    right at the bottom of the wheel, the wheel rotates clockwise (bottom -> left -> top -> right -> bottom).
 */
object HamsterFrames13x13 {

    const val MATRIX_SIZE = 13
    const val TOTAL_CELLS = MATRIX_SIZE * MATRIX_SIZE // 169

    val ROWS_13 = intArrayOf(5, 9, 11, 11, 13, 13, 13, 13, 13, 11, 11, 9, 5)

    private const val WHEEL_BRIGHTNESS = 75
    private const val HAMSTER_BRIGHTNESS = 255

    // 160 steps * 190 ms = 30.4 seconds seamless loop
    const val SLEEP_CYCLE_LENGTH = 160
    const val WHEEL_LOOP_STEPS = 12

    // Exact 36 outer rim coordinates on the 13x13 circular mask
    private val RIM_COORDS: List<Pair<Int, Int>> = listOf(
        Pair(0, 4), Pair(0, 5), Pair(0, 6), Pair(0, 7), Pair(0, 8),
        Pair(1, 2), Pair(1, 3), Pair(1, 9), Pair(1, 10),
        Pair(2, 1), Pair(2, 11),
        Pair(3, 1), Pair(3, 11),
        Pair(4, 0), Pair(4, 12),
        Pair(5, 0), Pair(5, 12),
        Pair(6, 0), Pair(6, 12),
        Pair(7, 0), Pair(7, 12),
        Pair(8, 0), Pair(8, 12),
        Pair(9, 1), Pair(9, 11),
        Pair(10, 1), Pair(10, 11),
        Pair(11, 2), Pair(11, 3), Pair(11, 9), Pair(11, 10),
        Pair(12, 4), Pair(12, 5), Pair(12, 6), Pair(12, 7), Pair(12, 8)
    )

    private val RIM_SET: Set<Pair<Int, Int>> = RIM_COORDS.toSet()

    // Exact 4 wheel spoke states ordered in CLOCKWISE (по часовой стрелке) rotation order:
    // Phase 0 (45° X) -> Phase 1 (Tilted CW) -> Phase 2 (90° '+' Cross) -> Phase 3 (Tilted CW 2)
    private val SPOKE_PHASES_CW: Array<List<Pair<Int, Int>>> = arrayOf(
        // Phase 0: 45° diagonal X-spokes
        listOf(
            Pair(2, 2), Pair(3, 3), Pair(4, 4), Pair(5, 5),
            Pair(2, 10), Pair(3, 9), Pair(4, 8), Pair(5, 7),
            Pair(6, 6),
            Pair(7, 5), Pair(8, 4), Pair(9, 3), Pair(10, 2),
            Pair(7, 7), Pair(8, 8), Pair(9, 9), Pair(10, 10)
        ),
        // Phase 1: Clockwise rotation +22.5° (Screenshot 4 spoke pattern)
        listOf(
            Pair(1, 8), Pair(2, 8), Pair(3, 7), Pair(4, 7), Pair(5, 7),
            Pair(4, 1), Pair(4, 2), Pair(5, 3), Pair(5, 4), Pair(5, 5),
            Pair(6, 5), Pair(6, 6), Pair(6, 7),
            Pair(7, 6), Pair(8, 5), Pair(9, 5), Pair(10, 4), Pair(11, 4),
            Pair(7, 8), Pair(7, 9), Pair(8, 10), Pair(8, 11)
        ),
        // Phase 2: Clockwise rotation +45° (90° orthogonal '+' cross spokes)
        listOf(
            Pair(1, 6), Pair(2, 6), Pair(3, 6), Pair(4, 6), Pair(5, 6),
            Pair(6, 1), Pair(6, 2), Pair(6, 3), Pair(6, 4), Pair(6, 5),
            Pair(6, 6),
            Pair(6, 7), Pair(6, 8), Pair(6, 9), Pair(6, 10), Pair(6, 11),
            Pair(7, 6), Pair(8, 6), Pair(9, 6), Pair(10, 6), Pair(11, 6)
        ),
        // Phase 3: Clockwise rotation +67.5° (Screenshot 3 spoke pattern)
        listOf(
            Pair(1, 4), Pair(2, 4), Pair(3, 5), Pair(4, 5), Pair(5, 5),
            Pair(4, 10), Pair(4, 11), Pair(5, 7), Pair(5, 8), Pair(5, 9),
            Pair(6, 6),
            Pair(7, 3), Pair(7, 4), Pair(7, 5), Pair(8, 1), Pair(8, 2),
            Pair(7, 7), Pair(8, 7), Pair(9, 8), Pair(10, 8), Pair(11, 8)
        )
    )

    fun isValidCell(r: Int, c: Int): Boolean {
        if (r !in 0 until MATRIX_SIZE || c !in 0 until MATRIX_SIZE) return false
        val ledsInRow = ROWS_13[r]
        val colStart = (MATRIX_SIZE - ledsInRow) / 2
        return c in colStart until (colStart + ledsInRow)
    }

    private fun buildWheelBase(spokePhase: Int): IntArray {
        val grid = IntArray(TOTAL_CELLS)
        for ((r, c) in RIM_COORDS) {
            grid[r * MATRIX_SIZE + c] = WHEEL_BRIGHTNESS
        }
        val phase = ((spokePhase % 4) + 4) % 4
        for ((r, c) in SPOKE_PHASES_CW[phase]) {
            if (isValidCell(r, c)) {
                grid[r * MATRIX_SIZE + c] = WHEEL_BRIGHTNESS
            }
        }
        return grid
    }

    /**
     * Generates a seamless 160-step (30.4-second) sleeping hamster animation.
     * Every 5 steps a single-pixel sleep particle spawns at row 8 and rises 1 row per step
     * (`r = 8 -> 7 -> 6 -> 5 -> 4 -> 3 -> 2 -> 1`) with a gentle sinusoidal drift before
     * leaving the top of the wheel. Wrapping from step 159 to step 0 is 100% seamless.
     */
    fun getSleepingFrame(stepIndex: Int): IntArray {
        val s = ((stepIndex % SLEEP_CYCLE_LENGTH) + SLEEP_CYCLE_LENGTH) % SLEEP_CYCLE_LENGTH
        val grid = buildWheelBase(spokePhase = 0)

        // Calm breathing every 10 steps (16 breaths over the 160-step cycle)
        val expandedBack = (s % 10) in 4..6
        val row9Cols = if (expandedBack) intArrayOf(6, 7, 8) else intArrayOf(6, 7)
        for (c in row9Cols) {
            grid[9 * MATRIX_SIZE + c] = HAMSTER_BRIGHTNESS
        }
        for (c in 5..8) {
            grid[10 * MATRIX_SIZE + c] = HAMSTER_BRIGHTNESS
        }
        for (c in 4..8) {
            grid[11 * MATRIX_SIZE + c] = HAMSTER_BRIGHTNESS
        }

        // 32 evenly spaced particle emitters across the 160-step cycle (every 5 steps)
        for (k in 0 until 32) {
            val spawnStep = k * 5
            val age = (s - spawnStep + SLEEP_CYCLE_LENGTH) % SLEEP_CYCLE_LENGTH
            if (age in 0..7) {
                val r = 8 - age // Rises strictly 1 row per step from row 8 up to row 1
                val wave = sin(2.0 * PI * (spawnStep / 160.0) * 3.0 + age * 0.45)
                val c = (7.8 + 1.6 * wave).roundToInt().coerceIn(4, 10)
                if (isValidCell(r, c)) {
                    grid[r * MATRIX_SIZE + c] = HAMSTER_BRIGHTNESS
                }
            }
        }

        return grid
    }

    /**
     * Generates a running hamster frame matching Screenshots 3 & 4, with clockwise wheel spoke rotation.
     */
    fun getRunningFrame(stepIndex: Int): IntArray {
        val phase = ((stepIndex % 4) + 4) % 4
        val grid = buildWheelBase(spokePhase = phase)

        val bodyPixels = listOf(
            Pair(8, 7),                                         // Ear
            Pair(9, 5), Pair(9, 6), Pair(9, 8),                 // Head & snout ((9,7) is dark eye)
            Pair(10, 4), Pair(10, 5), Pair(10, 6), Pair(10, 7), Pair(10, 8) // Torso
        )
        for ((r, c) in bodyPixels) {
            grid[r * MATRIX_SIZE + c] = HAMSTER_BRIGHTNESS
        }
        grid[9 * MATRIX_SIZE + 7] = 0 // Keep eye dark

        val legs = when (phase) {
            0 -> listOf(Pair(11, 3), Pair(11, 7))
            1 -> listOf(Pair(11, 4), Pair(11, 6)) // Screenshot 4 stride
            2 -> listOf(Pair(11, 5), Pair(11, 7))
            else -> listOf(Pair(11, 4), Pair(11, 8)) // Screenshot 3 stride
        }
        for ((r, c) in legs) {
            grid[r * MATRIX_SIZE + c] = HAMSTER_BRIGHTNESS
        }

        return grid
    }

    /**
     * Generates a frame where the hamster clings to the wheel and makes one full 360-degree
     * CLOCKWISE (по часовой стрелке) revolution (`loopStep` 0..11) along with the wheel:
     * Bottom (6 o'clock, 90°) -> Left wall (9 o'clock, 180°) -> Top (12 o'clock, 270°) -> Right wall (3 o'clock, 360°) -> Bottom (90°).
     */
    fun getWheelLoopFrame(loopStep: Int): IntArray {
        val step = ((loopStep % WHEEL_LOOP_STEPS) + WHEEL_LOOP_STEPS) % WHEEL_LOOP_STEPS
        val grid = buildWheelBase(spokePhase = step % 4)

        // Clockwise in screen coordinates (where Y points down and X points right) means INCREASING angle from 90°:
        // step 0 = 90° (bottom), step 3 = 180° (left wall), step 6 = 270° (top), step 9 = 360° (right wall)
        val angleRad = Math.toRadians(90.0 + step * (360.0 / WHEEL_LOOP_STEPS))
        val cx = 6.0 + 3.5 * cos(angleRad)
        val cy = 6.0 + 3.5 * sin(angleRad)

        for (r in 0 until MATRIX_SIZE) {
            for (c in 0 until MATRIX_SIZE) {
                if (!isValidCell(r, c)) continue
                if (RIM_SET.contains(Pair(r, c))) continue
                if (hypot(r - cy, c - cx) <= 1.65) {
                    grid[r * MATRIX_SIZE + c] = HAMSTER_BRIGHTNESS
                }
            }
        }
        return grid
    }

    fun toBitmap(frame169: IntArray): Bitmap {
        val pixels = IntArray(TOTAL_CELLS)
        for (i in 0 until TOTAL_CELLS) {
            val r = i / MATRIX_SIZE
            val c = i % MATRIX_SIZE
            val b = if (isValidCell(r, c)) frame169[i].coerceIn(0, 255) else 0
            pixels[i] = if (b > 0) Color.argb(255, b, b, b) else Color.TRANSPARENT
        }
        return Bitmap.createBitmap(pixels, MATRIX_SIZE, MATRIX_SIZE, Bitmap.Config.ARGB_8888)
    }
}
