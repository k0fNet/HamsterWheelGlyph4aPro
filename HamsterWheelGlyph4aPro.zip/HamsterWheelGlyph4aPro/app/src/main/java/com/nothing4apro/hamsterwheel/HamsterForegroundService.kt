package com.nothing4apro.hamsterwheel

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat

/**
 * Foreground Service that keeps the 13×13 Hamster Wheel animation alive at all times —
 * specifically when the screen is turned ON (`ACTION_SCREEN_ON`), when unlocked, and
 * during charging transitions (`ACTION_POWER_CONNECTED` / `ACTION_POWER_DISCONNECTED`).
 */
class HamsterForegroundService : Service() {

    companion object {
        private const val CHANNEL_ID = "hamster_glyph_channel"
        private const val NOTIFICATION_ID = 4041
        const val ACTION_STOP_SERVICE = "com.nothing4apro.hamsterwheel.STOP_SERVICE"

        fun startService(context: Context) {
            val intent = Intent(context, HamsterForegroundService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stopService(context: Context) {
            val intent = Intent(context, HamsterForegroundService::class.java)
            context.stopService(intent)
        }
    }

    private var wakeLock: PowerManager.WakeLock? = null

    private val dynamicReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                Intent.ACTION_POWER_CONNECTED -> {
                    HamsterAnimatorEngine.onPowerStateChanged(context, true)
                    updateNotification()
                }
                Intent.ACTION_POWER_DISCONNECTED -> {
                    HamsterAnimatorEngine.onPowerStateChanged(context, false)
                    updateNotification()
                }
                Intent.ACTION_BATTERY_CHANGED -> {
                    val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                    val plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0)
                    val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                            status == BatteryManager.BATTERY_STATUS_FULL ||
                            plugged != 0
                    HamsterAnimatorEngine.onPowerStateChanged(context, isCharging)
                }
                Intent.ACTION_SCREEN_ON,
                Intent.ACTION_USER_PRESENT -> {
                    // Screen just turned on! Re-assert matrix frame immediately so it never stops
                    HamsterAnimatorEngine.onScreenWake()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification = buildNotification()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        // Register dynamic receivers for instant power & screen-wake detection
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_POWER_CONNECTED)
            addAction(Intent.ACTION_POWER_DISCONNECTED)
            addAction(Intent.ACTION_BATTERY_CHANGED)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_USER_PRESENT)
        }
        registerReceiver(dynamicReceiver, filter)

        // Acquire a lightweight partial wake lock only to ensure smooth deceleration when unplugged with screen off
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "HamsterWheelGlyph::AnimLock").apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 1000L) // Renewed or held gently
        }

        HamsterAnimatorEngine.start(applicationContext)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP_SERVICE) {
            HamsterAnimatorEngine.stop()
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            return START_NOT_STICKY
        }
        HamsterAnimatorEngine.start(applicationContext)
        updateNotification()
        return START_STICKY
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(dynamicReceiver)
        } catch (_: Throwable) {}
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Throwable) {}
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Hamster Glyph Matrix Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Поддерживает работу анимации хомячка на матрице 13×13 при включенном экране"
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingOpen = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, HamsterForegroundService::class.java).apply {
            action = ACTION_STOP_SERVICE
        }
        val pendingStop = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val statusText = when (HamsterAnimatorEngine.currentState) {
            HamsterAnimatorEngine.State.RUNNING -> "Хомячок бежит в колесе (Зарядка подключена)"
            HamsterAnimatorEngine.State.DECELERATING -> "Колесо плавно останавливается..."
            HamsterAnimatorEngine.State.SLEEPING -> "Хомячок спит в колесе (Ожидание зарядки)"
        }

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_toy_preview)
            .setContentTitle("Hamster Wheel · Glyph 13×13")
            .setContentText(statusText)
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(pendingOpen)
            .addAction(0, "Выключить", pendingStop)
            .build()
    }

    private fun updateNotification() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification())
    }
}
