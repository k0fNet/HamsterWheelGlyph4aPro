package com.nothing4apro.hamsterwheel

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/**
 * Manifest BroadcastReceiver that wakes up the Hamster Wheel service on boot or when
 * a charger is plugged/unplugged.
 */
class PowerStateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED -> {
                HamsterForegroundService.startService(context)
            }
            Intent.ACTION_POWER_CONNECTED -> {
                HamsterForegroundService.startService(context)
                HamsterAnimatorEngine.onPowerStateChanged(context, true)
            }
            Intent.ACTION_POWER_DISCONNECTED -> {
                HamsterForegroundService.startService(context)
                HamsterAnimatorEngine.onPowerStateChanged(context, false)
            }
        }
    }
}
