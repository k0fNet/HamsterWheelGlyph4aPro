package com.nothing4apro.hamsterwheel

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.nothing.ketchum.Glyph
import com.nothing.ketchum.GlyphMatrixFrame
import com.nothing.ketchum.GlyphMatrixManager
import com.nothing.ketchum.GlyphMatrixObject
import java.util.concurrent.CopyOnWriteArraySet

/**
 * Core state machine and physics loop for the 13×13 Charging Hamster Glyph Toy.
 *
 * States:
 * 1. SLEEPING: Hamster sleeps at the bottom of the wheel while single-pixel sleep particles
 *    slowly drift upward and exit the top of the screen (~190 ms per step).
 * 2. RUNNING: When charging, the wheel spokes spin rapidly and the hamster runs (~70 ms per step).
 * 3. WHEEL_LOOP_STOP: When unplugged, the hamster clings to the wheel and makes one full 360°
 *    revolution with the wheel as the wheel slows down from 80 ms to 260 ms per step, then goes to sleep.
 */
object HamsterAnimatorEngine {

    private const val TAG = "HamsterAnimatorEngine"
    private const val PREFS_NAME = "hamster_glyph_prefs"
    private const val KEY_ENABLED = "glyph_enabled"
    private const val KEY_SCREEN_ON_PERSIST = "screen_on_persist"
    private const val KEY_ONLY_WHILE_CHARGING = "only_while_charging"

    enum class State {
        SLEEPING,
        RUNNING,
        WHEEL_LOOP_STOP,
        DISABLED
    }

    interface FrameListener {
        fun onFrameUpdated(
            frame169: IntArray,
            state: State,
            frameDelayMs: Long,
            isCharging: Boolean,
            isEnabled: Boolean
        )
    }

    private val handler = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArraySet<FrameListener>()

    private var appContext: Context? = null
    private var glyphManager: GlyphMatrixManager? = null
    private var isSdkConnected = false
    private var isLoopRunning = false
    var isToyServiceBound: Boolean = false
        private set

    var isGlyphEnabled: Boolean = true
        private set

    var keepScreenOnActive: Boolean = true
        private set

    var onlyShowWhileCharging: Boolean = false
        private set

    var currentState: State = State.SLEEPING
        private set

    var isChargingNow: Boolean = false
        private set

    var manualChargingOverride: Boolean? = null
        private set

    private var runStepIndex = 0
    private var sleepStepIndex = 0
    private var wheelLoopStep = 0

    // Timing constants matching the reference video
    private const val SLEEP_STEP_DELAY_MS = 190L
    private const val RUN_STEP_DELAY_MS = 70L

    private var currentDelayMs: Long = SLEEP_STEP_DELAY_MS
    private var lastFrame169: IntArray = HamsterFrames13x13.getSleepingFrame(0)

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (!isLoopRunning) return
            try {
                stepSimulation()
            } catch (t: Throwable) {
                Log.e(TAG, "Error in animation tick", t)
            } finally {
                if (isLoopRunning && isGlyphEnabled) {
                    handler.postDelayed(this, currentDelayMs)
                }
            }
        }
    }

    fun loadPrefs(context: Context) {
        val prefs = context.applicationContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        isGlyphEnabled = prefs.getBoolean(KEY_ENABLED, true)
        keepScreenOnActive = prefs.getBoolean(KEY_SCREEN_ON_PERSIST, true)
        onlyShowWhileCharging = prefs.getBoolean(KEY_ONLY_WHILE_CHARGING, false)
    }

    fun setGlyphEnabled(context: Context, enabled: Boolean) {
        val ctx = context.applicationContext
        appContext = ctx
        isGlyphEnabled = enabled
        ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ENABLED, enabled)
            .apply()

        if (!enabled) {
            currentState = State.DISABLED
            handler.removeCallbacks(tickRunnable)
            clearHardwareMatrix()
            HamsterForegroundService.stopService(ctx)
            notifyListeners()
        } else {
            currentState = if (isEffectiveCharging()) State.RUNNING else State.SLEEPING
            HamsterForegroundService.startService(ctx)
            start(ctx)
        }
    }

    fun setKeepScreenOnActive(context: Context, active: Boolean) {
        val ctx = context.applicationContext
        keepScreenOnActive = active
        ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_SCREEN_ON_PERSIST, active)
            .apply()
        if (!active && !isToyServiceBound) {
            clearAppMatrixOnly()
        } else if (active && isGlyphEnabled) {
            pushFrameToHardware(lastFrame169)
        }
    }

    fun setOnlyShowWhileCharging(context: Context, onlyCharging: Boolean) {
        val ctx = context.applicationContext
        onlyShowWhileCharging = onlyCharging
        ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putBoolean(KEY_ONLY_WHILE_CHARGING, onlyCharging)
            .apply()
        pushFrameToHardware(lastFrame169)
    }

    fun start(context: Context) {
        val ctx = context.applicationContext
        appContext = ctx
        loadPrefs(ctx)
        syncBatteryChargingState(ctx)

        if (!isGlyphEnabled) {
            currentState = State.DISABLED
            clearHardwareMatrix()
            notifyListeners()
            return
        }

        if (glyphManager == null) {
            initGlyphSdk(ctx)
        }

        if (!isLoopRunning) {
            isLoopRunning = true
            handler.removeCallbacks(tickRunnable)
            handler.post(tickRunnable)
        }
    }

    fun stop() {
        isLoopRunning = false
        handler.removeCallbacks(tickRunnable)
        clearHardwareMatrix()
        try {
            glyphManager?.unInit()
        } catch (t: Throwable) {
            Log.w(TAG, "Error uninitializing GlyphMatrixManager", t)
        }
        glyphManager = null
        isSdkConnected = false
    }

    /**
     * Called when Nothing OS binds or unbinds HamsterToyService.
     * When the user switches to a DIFFERENT Glyph Toy in Nothing OS settings, `onUnbind` fires
     * (`bound = false`). We immediately release `closeAppMatrix()` if `keepScreenOnActive` is off
     * or if another toy took over while the screen is off, so our hamster doesn't override other toys!
     */
    fun onToyBindStateChanged(context: Context, bound: Boolean) {
        isToyServiceBound = bound
        if (!bound) {
            // Release app matrix layer when unbound so other selected Glyph Toys are never blocked
            clearAppMatrixOnly()
        } else if (isGlyphEnabled) {
            start(context)
        }
    }

    fun addListener(listener: FrameListener) {
        listeners.add(listener)
        listener.onFrameUpdated(lastFrame169, currentState, currentDelayMs, isEffectiveCharging(), isGlyphEnabled)
    }

    fun removeListener(listener: FrameListener) {
        listeners.remove(listener)
    }

    fun setManualOverride(overrideCharging: Boolean?) {
        manualChargingOverride = overrideCharging
        applyChargingTransition(isEffectiveCharging())
    }

    fun onPowerStateChanged(context: Context, charging: Boolean) {
        appContext = context.applicationContext
        isChargingNow = charging
        if (manualChargingOverride == null) {
            applyChargingTransition(charging)
        }
    }

    fun onScreenWake() {
        if (!isGlyphEnabled || !keepScreenOnActive) return
        handler.post { pushFrameToHardware(lastFrame169) }
        handler.postDelayed({ pushFrameToHardware(lastFrame169) }, 220L)
    }

    private fun isEffectiveCharging(): Boolean {
        return manualChargingOverride ?: isChargingNow
    }

    fun syncBatteryChargingState(context: Context) {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL ||
                plugged != 0
        isChargingNow = charging
        applyChargingTransition(isEffectiveCharging())
    }

    private fun applyChargingTransition(activeCharging: Boolean) {
        if (!isGlyphEnabled) {
            currentState = State.DISABLED
            return
        }
        if (activeCharging) {
            if (currentState != State.RUNNING) {
                currentState = State.RUNNING
                currentDelayMs = RUN_STEP_DELAY_MS
                if (isLoopRunning) {
                    handler.removeCallbacks(tickRunnable)
                    handler.post(tickRunnable)
                }
            }
        } else {
            if (currentState == State.RUNNING) {
                // Unplugged! Hamster clings to the wheel and makes 1 full circle (12 steps) as wheel slows down
                currentState = State.WHEEL_LOOP_STOP
                wheelLoopStep = 0
                currentDelayMs = 80L
                if (isLoopRunning) {
                    handler.removeCallbacks(tickRunnable)
                    handler.post(tickRunnable)
                }
            }
        }
    }

    private fun stepSimulation() {
        if (!isGlyphEnabled) {
            currentState = State.DISABLED
            clearHardwareMatrix()
            notifyListeners()
            return
        }

        val activeCharging = isEffectiveCharging()
        if (activeCharging && currentState != State.RUNNING) {
            currentState = State.RUNNING
            currentDelayMs = RUN_STEP_DELAY_MS
        } else if (!activeCharging && currentState == State.RUNNING) {
            currentState = State.WHEEL_LOOP_STOP
            wheelLoopStep = 0
            currentDelayMs = 80L
        }

        when (currentState) {
            State.SLEEPING -> {
                currentDelayMs = SLEEP_STEP_DELAY_MS
                sleepStepIndex = (sleepStepIndex + 1) % HamsterFrames13x13.SLEEP_CYCLE_LENGTH
                lastFrame169 = HamsterFrames13x13.getSleepingFrame(sleepStepIndex)
            }

            State.RUNNING -> {
                currentDelayMs = RUN_STEP_DELAY_MS
                runStepIndex = (runStepIndex + 1) and 3
                lastFrame169 = HamsterFrames13x13.getRunningFrame(runStepIndex)
            }

            State.WHEEL_LOOP_STOP -> {
                lastFrame169 = HamsterFrames13x13.getWheelLoopFrame(wheelLoopStep)
                wheelLoopStep++
                // Smoothly slow down the wheel as it completes the 360-degree turn (80ms -> ~250ms)
                currentDelayMs = 80L + (wheelLoopStep * 14L)
                if (wheelLoopStep >= HamsterFrames13x13.WHEEL_LOOP_STEPS) {
                    currentState = State.SLEEPING
                    sleepStepIndex = 0
                    currentDelayMs = SLEEP_STEP_DELAY_MS
                }
            }

            State.DISABLED -> {
                lastFrame169 = IntArray(HamsterFrames13x13.TOTAL_CELLS)
            }
        }

        pushFrameToHardware(lastFrame169)
        notifyListeners()
    }

    private fun notifyListeners() {
        val charging = isEffectiveCharging()
        for (listener in listeners) {
            listener.onFrameUpdated(lastFrame169, currentState, currentDelayMs, charging, isGlyphEnabled)
        }
    }

    private fun initGlyphSdk(context: Context) {
        try {
            val gm = GlyphMatrixManager.getInstance(context)
            glyphManager = gm
            gm.init(object : GlyphMatrixManager.Callback {
                override fun onServiceConnected(componentName: ComponentName?) {
                    try {
                        gm.register(Glyph.DEVICE_25111p)
                        isSdkConnected = true
                        Log.i(TAG, "Registered DEVICE_25111p (Phone 4a Pro 13x13)")
                        if (isGlyphEnabled) {
                            pushFrameToHardware(lastFrame169)
                        }
                    } catch (t: Throwable) {
                        Log.e(TAG, "Failed to register DEVICE_25111p", t)
                    }
                }

                override fun onServiceDisconnected(componentName: ComponentName?) {
                    isSdkConnected = false
                }
            })
        } catch (t: Throwable) {
            Log.e(TAG, "GlyphMatrix SDK init failed", t)
        }
    }

    fun clearAppMatrixOnly() {
        try {
            glyphManager?.closeAppMatrix()
        } catch (_: Throwable) {}
    }

    fun clearHardwareMatrix() {
        val ctx = appContext
        val gm = glyphManager
        if (ctx != null && gm != null && isSdkConnected) {
            try {
                val blankBitmap = HamsterFrames13x13.toBitmap(IntArray(HamsterFrames13x13.TOTAL_CELLS))
                val obj = GlyphMatrixObject.Builder()
                    .setImageSource(blankBitmap)
                    .setBrightness(0)
                    .build()
                val emptyFrame = GlyphMatrixFrame.Builder().addTop(obj).build(ctx).render()
                gm.setMatrixFrame(emptyFrame)
            } catch (_: Throwable) {}
            try {
                gm.closeAppMatrix()
            } catch (_: Throwable) {}
        }
    }

    private fun pushFrameToHardware(frame169: IntArray) {
        val ctx = appContext ?: return
        val gm = glyphManager ?: return
        if (!isSdkConnected || !isGlyphEnabled) return

        // If "Only show while charging" is enabled and we are sleeping (unplugged), keep physical LEDs dark
        val displayArray = if (onlyShowWhileCharging && currentState == State.SLEEPING) {
            IntArray(HamsterFrames13x13.TOTAL_CELLS)
        } else {
            frame169
        }

        try {
            val bitmap = HamsterFrames13x13.toBitmap(displayArray)
            val matrixObject = GlyphMatrixObject.Builder()
                .setImageSource(bitmap)
                .setPosition(0, 0)
                .setScale(100)
                .setOrientation(0)
                .setBrightness(255)
                .build()

            val frame = GlyphMatrixFrame.Builder()
                .addTop(matrixObject)
                .build(ctx)

            val rendered = frame.render()

            // 1. If bound as the active Glyph Toy in Nothing OS Settings, update Toy layer
            if (isToyServiceBound) {
                gm.setMatrixFrame(rendered)
            }

            // 2. Only push to App Matrix layer if keepScreenOnActive is enabled
            if (keepScreenOnActive) {
                gm.setAppMatrixFrame(rendered)
            } else {
                gm.closeAppMatrix()
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Could not push frame to GlyphMatrixManager", t)
        }
    }
}
