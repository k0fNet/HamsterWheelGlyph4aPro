package com.nothing4apro.hamsterwheel

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.nothing.ketchum.Glyph
import com.nothing.ketchum.GlyphMatrixFrame
import com.nothing.ketchum.GlyphMatrixManager
import com.nothing.ketchum.GlyphMatrixObject
import java.util.concurrent.CopyOnWriteArraySet
import kotlin.math.roundToLong

/**
 * Core state machine and physics loop for the 13×13 Hamster Wheel Glyph Matrix Toy.
 *
 * Behavior:
 * 1. SLEEPING (Default when unplugged): Hamster sleeps curled up at the bottom of the wheel
 *    with a calm breathing cycle (~900 ms per frame).
 * 2. RUNNING (When charger is connected): Hamster wakes up immediately and runs at full speed
 *    (~85 ms per frame) as the wheel spins.
 * 3. DECELERATING (When charger is unplugged): The wheel and hamster gradually lose momentum
 *    over ~4.2 seconds (frame delay smoothly increases from 85 ms -> 480 ms) before curling
 *    back to sleep.
 * 4. SCREEN-ON PERSISTENCE: Pushes frames via BOTH `setMatrixFrame` (when bound as an AOD Toy)
 *    and `setAppMatrixFrame` (when the screen is turned on / unlocked), so waking the screen
 *    never interrupts the animation.
 */
object HamsterAnimatorEngine {

    private const val TAG = "HamsterAnimatorEngine"

    enum class State {
        SLEEPING,
        RUNNING,
        DECELERATING
    }

    interface FrameListener {
        fun onFrameUpdated(frame169: IntArray, state: State, frameDelayMs: Long, isCharging: Boolean)
    }

    private val handler = Handler(Looper.getMainLooper())
    private val listeners = CopyOnWriteArraySet<FrameListener>()

    private var appContext: Context? = null
    private var glyphManager: GlyphMatrixManager? = null
    private var isSdkConnected = false
    private var isLoopRunning = false
    private var isToyServiceBound = false

    var currentState: State = State.SLEEPING
        private set

    var isChargingNow: Boolean = false
        private set

    // Manual simulation override from inside the companion UI for instant testing without cable
    var manualChargingOverride: Boolean? = null
        private set

    private var stepIndex = 0
    private var breathIndex = 0

    // Physics parameters (milliseconds per frame)
    private const val SLEEP_FRAME_DELAY_MS = 900L
    private const val RUN_MIN_DELAY_MS = 85L
    private const val DECEL_STOP_DELAY_MS = 480L
    private const val DECEL_MULTIPLIER = 1.14 // Smooth exponential slowdown (~14 steps / ~4.2 seconds)

    private var currentDelayMs: Long = SLEEP_FRAME_DELAY_MS
    private var lastFrame169: IntArray = HamsterFrames13x13.getSleepingFrame(0)

    private val tickRunnable = object : Runnable {
        override fun run() {
            if (!isLoopRunning) return
            try {
                stepSimulation()
            } catch (t: Throwable) {
                Log.e(TAG, "Error in animation tick", t)
            } finally {
                if (isLoopRunning) {
                    handler.postDelayed(this, currentDelayMs)
                }
            }
        }
    }

    fun start(context: Context) {
        val ctx = context.applicationContext
        appContext = ctx
        syncBatteryChargingState(ctx)

        if (glyphManager == null) {
            initGlyphSdk(ctx)
        }

        if (!isLoopRunning) {
            isLoopRunning = true
            handler.removeCallbacks(tickRunnable)
            handler.post(tickRunnable)
        }
    }

    fun stop() {
        isLoopRunning = false
        handler.removeCallbacks(tickRunnable)
        try {
            glyphManager?.closeAppMatrix()
        } catch (_: Throwable) {}
        try {
            glyphManager?.unInit()
        } catch (t: Throwable) {
            Log.w(TAG, "Error shutting down GlyphMatrixManager", t)
        }
        glyphManager = null
        isSdkConnected = false
    }

    fun setToyBound(bound: Boolean) {
        isToyServiceBound = bound
    }

    fun addListener(listener: FrameListener) {
        listeners.add(listener)
        listener.onFrameUpdated(lastFrame169, currentState, currentDelayMs, isEffectiveCharging())
    }

    fun removeListener(listener: FrameListener) {
        listeners.remove(listener)
    }

    fun setManualOverride(overrideCharging: Boolean?) {
        manualChargingOverride = overrideCharging
        applyChargingTransition(isEffectiveCharging())
    }

    fun onPowerStateChanged(context: Context, charging: Boolean) {
        appContext = context.applicationContext
        isChargingNow = charging
        if (manualChargingOverride == null) {
            applyChargingTransition(charging)
        }
    }

    /**
     * Called when screen turns ON (`ACTION_SCREEN_ON`) or user unlocks phone (`ACTION_USER_PRESENT`).
     * Immediately re-asserts the matrix frame so Nothing OS does not blank the back LEDs.
     */
    fun onScreenWake() {
        handler.post {
            pushFrameToHardware(lastFrame169)
        }
        handler.postDelayed({
            pushFrameToHardware(lastFrame169)
        }, 250L)
    }

    private fun isEffectiveCharging(): Boolean {
        return manualChargingOverride ?: isChargingNow
    }

    fun syncBatteryChargingState(context: Context) {
        val intent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                status == BatteryManager.BATTERY_STATUS_FULL ||
                plugged != 0
        isChargingNow = charging
        applyChargingTransition(isEffectiveCharging())
    }

    private fun applyChargingTransition(activeCharging: Boolean) {
        if (activeCharging) {
            if (currentState != State.RUNNING) {
                currentState = State.RUNNING
                currentDelayMs = RUN_MIN_DELAY_MS
                if (isLoopRunning) {
                    handler.removeCallbacks(tickRunnable)
                    handler.post(tickRunnable)
                }
            }
        } else {
            if (currentState == State.RUNNING) {
                currentState = State.DECELERATING
                currentDelayMs = 100L
            }
        }
    }

    private fun stepSimulation() {
        val activeCharging = isEffectiveCharging()
        if (activeCharging && currentState != State.RUNNING) {
            currentState = State.RUNNING
            currentDelayMs = RUN_MIN_DELAY_MS
        } else if (!activeCharging && currentState == State.RUNNING) {
            currentState = State.DECELERATING
            currentDelayMs = 100L
        }

        when (currentState) {
            State.SLEEPING -> {
                currentDelayMs = SLEEP_FRAME_DELAY_MS
                breathIndex = (breathIndex + 1) and 1
                lastFrame169 = HamsterFrames13x13.getSleepingFrame(breathIndex)
            }

            State.RUNNING -> {
                currentDelayMs = RUN_MIN_DELAY_MS
                stepIndex = (stepIndex + 1) and 3
                lastFrame169 = HamsterFrames13x13.getRunningFrame(stepIndex)
            }

            State.DECELERATING -> {
                stepIndex = (stepIndex + 1) and 3
                lastFrame169 = HamsterFrames13x13.getRunningFrame(stepIndex)
                val nextDelay = (currentDelayMs * DECEL_MULTIPLIER).roundToLong()
                if (nextDelay >= DECEL_STOP_DELAY_MS) {
                    currentState = State.SLEEPING
                    currentDelayMs = SLEEP_FRAME_DELAY_MS
                } else {
                    currentDelayMs = nextDelay
                }
            }
        }

        pushFrameToHardware(lastFrame169)

        for (listener in listeners) {
            listener.onFrameUpdated(lastFrame169, currentState, currentDelayMs, activeCharging)
        }
    }

    private fun initGlyphSdk(context: Context) {
        try {
            val gm = GlyphMatrixManager.getInstance(context)
            glyphManager = gm
            gm.init(object : GlyphMatrixManager.Callback {
                override fun onServiceConnected(componentName: ComponentName?) {
                    try {
                        // Explicitly register for Nothing Phone (4a) Pro (13x13 matrix, 137 LEDs)
                        gm.register(Glyph.DEVICE_25111p)
                        isSdkConnected = true
                        Log.i(TAG, "Registered with GlyphMatrixManager for DEVICE_25111p (Phone 4a Pro 13x13)")
                        pushFrameToHardware(lastFrame169)
                    } catch (t: Throwable) {
                        Log.e(TAG, "Failed to register DEVICE_25111p", t)
                    }
                }

                override fun onServiceDisconnected(componentName: ComponentName?) {
                    isSdkConnected = false
                    Log.w(TAG, "GlyphMatrixManager service disconnected")
                }
            })
        } catch (t: Throwable) {
            Log.e(TAG, "GlyphMatrix SDK initialization failed", t)
        }
    }

    private fun pushFrameToHardware(frame169: IntArray) {
        val ctx = appContext ?: return
        val gm = glyphManager ?: return
        if (!isSdkConnected) return

        try {
            val bitmap = HamsterFrames13x13.toBitmap(frame169)
            val matrixObject = GlyphMatrixObject.Builder()
                .setImageSource(bitmap)
                .setPosition(0, 0)
                .setScale(100)
                .setOrientation(0)
                .setBrightness(255)
                .build()

            val frame = GlyphMatrixFrame.Builder()
                .addTop(matrixObject)
                .build(ctx)

            val rendered = frame.render()

            // 1. Always push via setAppMatrixFrame so animation continues when screen is ON
            gm.setAppMatrixFrame(rendered)

            // 2. If currently bound as an active Glyph Toy / AOD Toy, also push via setMatrixFrame
            if (isToyServiceBound) {
                gm.setMatrixFrame(rendered)
            }
        } catch (t: Throwable) {
            Log.w(TAG, "Could not push frame to GlyphMatrixManager", t)
        }
    }
}
