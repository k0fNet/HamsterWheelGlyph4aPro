package com.nothing4apro.hamsterwheel

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.min

/**
 * Custom View that renders the exact 13×13 circular Nothing Phone (4a) Pro Glyph Matrix
 * (137 active mini-LEDs) in real time on the phone screen.
 */
class GlyphMatrixPreviewView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var frame169 = IntArray(HamsterFrames13x13.TOTAL_CELLS)
    private val housingPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#121215")
        style = Paint.Style.FILL
    }
    private val rimStrokePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#2A2A30")
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }
    private val ledPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
    }

    fun updateFrame(newFrame: IntArray) {
        if (newFrame.size == HamsterFrames13x13.TOTAL_CELLS) {
            System.arraycopy(newFrame, 0, frame169, 0, newFrame.size)
            postInvalidateOnAnimation()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val size = min(width, height).toFloat()
        val cx = width / 2f
        val cy = height / 2f
        val radius = size * 0.47f

        // Circular Glyph Matrix housing
        canvas.drawCircle(cx, cy, radius, housingPaint)
        canvas.drawCircle(cx, cy, radius, rimStrokePaint)

        val gridSpan = radius * 1.72f
        val cellStep = gridSpan / HamsterFrames13x13.MATRIX_SIZE
        val startX = cx - gridSpan / 2f + cellStep / 2f
        val startY = cy - gridSpan / 2f + cellStep / 2f
        val ledRadius = cellStep * 0.36f

        for (r in 0 until HamsterFrames13x13.MATRIX_SIZE) {
            for (c in 0 until HamsterFrames13x13.MATRIX_SIZE) {
                if (!HamsterFrames13x13.isValidCell(r, c)) continue
                val x = startX + c * cellStep
                val y = startY + r * cellStep
                val brightness = frame169[r * HamsterFrames13x13.MATRIX_SIZE + c].coerceIn(0, 255)

                if (brightness > 0) {
                    val alpha = (55 + (brightness * 200) / 255).coerceIn(0, 255)
                    ledPaint.color = Color.argb(alpha, 255, 255, 255)
                } else {
                    ledPaint.color = Color.parseColor("#222228")
                }
                canvas.drawCircle(x, y, ledRadius, ledPaint)
            }
        }
    }
}
